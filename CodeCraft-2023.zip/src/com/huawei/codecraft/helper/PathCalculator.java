package com.huawei.codecraft.helper;

import java.util.List;

import com.huawei.codecraft.entity.CraftTable;
import com.huawei.codecraft.entity.Robot;
import com.huawei.codecraft.entity.Scheme;

public class PathCalculator {
    public List<List<Scheme>> getBestScheme(Robot[] robots, CraftTable[] tables, double[][] trafficTime,
            double[][] expectProfit) {

        return null;
    }
}
